# Site-Receita
Este é um repositório destinado á atividade da Etec de criar um site com uma Receita

Alunos: Flávio Gustavo 1F

Beatriz Vitória 1F
